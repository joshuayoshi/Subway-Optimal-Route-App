# Subway-Optimal-Route-App
Bellevue College Capstone Project 2022-2023 group 11

This app will assist subway users with getting around the city. It is still in early stages of development, so it is still uncertain how some things will be done.