def seven():
    return 7

def eight():
    return 8

def input(i=-1):
    return i